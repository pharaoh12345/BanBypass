!!!!!!!!!!! DEVELOPED BY @ja al#3617 !!!!!!!!!!!!!!!

ONLY WORKS ON VANILLA SERVERS (1.18.2 - 1.19)

INSTRUCTIONS:

1. Run as Admin
2. Type in username of account that needs to be unbanned when prompted 
3. Enter IP of server to unban from

!!!!!!!!!!! DEVELOPED BY @ja al#3617 !!!!!!!!!!!!!!!